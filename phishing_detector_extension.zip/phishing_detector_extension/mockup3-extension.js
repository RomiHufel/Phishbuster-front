document.addEventListener('DOMContentLoaded', () => {
    // Obtiene la última URL almacenada y la muestra
    chrome.storage.local.get("lastUrl", (data) => {
      document.getElementById("storedUrl").textContent = data.lastUrl || "No se ha almacenado ninguna URL aun";
    });
  });
  